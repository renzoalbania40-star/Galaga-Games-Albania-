from tkinter import *
import random

# =========================
# WINDOW
# =========================
root = Tk()
root.title("Galaga Python Game")
root.geometry("600x700")
root.config(bg="black")

canvas = Canvas(root, width=600, height=700, bg="black")
canvas.pack()

# =========================
# BACKGROUND STARS
# =========================
stars = []

for i in range(100):
    x = random.randint(0, 600)
    y = random.randint(0, 700)

    star = canvas.create_oval(
        x, y, x+2, y+2,
        fill="white",
        outline="white"
    )

    stars.append(star)

# =========================
# SCORE & LIVES
# =========================
score = 0
lives = 3

score_text = canvas.create_text(
    80, 20,
    text="Score: 0",
    fill="white",
    font=("Arial", 18, "bold")
)

lives_text = canvas.create_text(
    520, 20,
    text="Lives: 3",
    fill="white",
    font=("Arial", 18, "bold")
)

# =========================
# PLAYER SPACESHIP
# =========================
player = canvas.create_polygon(
    300, 620,
    270, 670,
    330, 670,
    fill="cyan",
    outline="white",
    width=2
)

player_speed = 12

# =========================
# VARIABLES
# =========================
bullets = []
enemies = []
explosions = []

left_pressed = False
right_pressed = False

game_running = True

game_over_text = None

# =========================
# CONTROLS
# =========================
def key_press(event):
    global left_pressed, right_pressed

    if event.keysym == "Left":
        left_pressed = True

    if event.keysym == "Right":
        right_pressed = True

    if event.keysym == "space":
        shoot()

    if event.keysym.lower() == "r":
        restart_game()

def key_release(event):
    global left_pressed, right_pressed

    if event.keysym == "Left":
        left_pressed = False

    if event.keysym == "Right":
        right_pressed = False

# =========================
# SHOOT BULLETS
# =========================
def shoot():
    if not game_running:
        return

    coords = canvas.coords(player)

    x = coords[0]

    bullet = canvas.create_rectangle(
        x - 3, 590,
        x + 3, 610,
        fill="yellow",
        outline="yellow"
    )

    bullets.append(bullet)

# =========================
# CREATE ENEMIES
# =========================
def create_enemy():
    x = random.randint(50, 550)

    enemy = canvas.create_oval(
        x, 50,
        x + 40, 90,
        fill="red",
        outline="white",
        width=2
    )

    enemies.append(enemy)

# =========================
# EXPLOSION EFFECT
# =========================
def create_explosion(x, y):
    explosion = canvas.create_oval(
        x-20, y-20,
        x+20, y+20,
        fill="orange",
        outline="yellow",
        width=3
    )

    explosions.append(explosion)

    root.after(
        150,
        lambda: remove_explosion(explosion)
    )

def remove_explosion(explosion):
    if explosion in explosions:
        canvas.delete(explosion)
        explosions.remove(explosion)

# =========================
# GAME OVER
# =========================
def game_over():
    global game_running, game_over_text

    game_running = False

    game_over_text = canvas.create_text(
        300, 350,
        text="GAME OVER\nPress R to Restart",
        fill="white",
        font=("Arial", 30, "bold"),
        justify="center"
    )

# =========================
# RESTART GAME
# =========================
def restart_game():
    global score, lives, game_running, game_over_text

    if game_running:
        return

    # Remove enemies
    for enemy in enemies:
        canvas.delete(enemy)

    enemies.clear()

    # Remove bullets
    for bullet in bullets:
        canvas.delete(bullet)

    bullets.clear()

    # Remove explosions
    for explosion in explosions:
        canvas.delete(explosion)

    explosions.clear()

    # Reset score/lives
    score = 0
    lives = 3

    canvas.itemconfig(score_text, text="Score: 0")
    canvas.itemconfig(lives_text, text="Lives: 3")

    # Remove game over text
    if game_over_text:
        canvas.delete(game_over_text)

    # Reset player position
    canvas.coords(
        player,
        300, 620,
        270, 670,
        330, 670
    )

    game_running = True

    update_game()

# =========================
# MAIN GAME LOOP
# =========================
def update_game():
    global score, lives, game_running

    if not game_running:
        return

    # Move stars
    for star in stars:
        canvas.move(star, 0, 2)

        sx1, sy1, sx2, sy2 = canvas.coords(star)

        if sy1 > 700:
            canvas.coords(
                star,
                random.randint(0, 600),
                0,
                random.randint(0, 600)+2,
                2
            )

    # Player movement
    coords = canvas.coords(player)

    px = coords[0]

    if left_pressed and px > 30:
        canvas.move(player, -player_speed, 0)

    if right_pressed and px < 570:
        canvas.move(player, player_speed, 0)

    # Move bullets
    for bullet in bullets[:]:
        canvas.move(bullet, 0, -15)

        bx1, by1, bx2, by2 = canvas.coords(bullet)

        if by1 < 0:
            canvas.delete(bullet)
            bullets.remove(bullet)

    # Create enemies
    if random.randint(1, 20) == 1:
        create_enemy()

    # Move enemies
    for enemy in enemies[:]:
        canvas.move(enemy, 0, 4)

        ex1, ey1, ex2, ey2 = canvas.coords(enemy)

        # Enemy reached bottom
        if ey2 >= 700:
            canvas.delete(enemy)

            if enemy in enemies:
                enemies.remove(enemy)

            lives -= 1

            canvas.itemconfig(
                lives_text,
                text=f"Lives: {lives}"
            )

            if lives <= 0:
                game_over()

        # Collision with player
        pcoords = canvas.coords(player)

        px = pcoords[0]
        py = pcoords[1]

        if (
            ex2 > px - 30 and
            ex1 < px + 30 and
            ey2 > py - 20 and
            ey1 < py + 40
        ):

            create_explosion(px, py)

            game_over()

    # Bullet collision
    for bullet in bullets[:]:
        bx1, by1, bx2, by2 = canvas.coords(bullet)

        for enemy in enemies[:]:
            ex1, ey1, ex2, ey2 = canvas.coords(enemy)

            if (
                bx2 > ex1 and
                bx1 < ex2 and
                by2 > ey1 and
                by1 < ey2
            ):

                # Explosion
                create_explosion(
                    (ex1 + ex2) / 2,
                    (ey1 + ey2) / 2
                )

                # Delete objects
                canvas.delete(bullet)
                canvas.delete(enemy)

                if bullet in bullets:
                    bullets.remove(bullet)

                if enemy in enemies:
                    enemies.remove(enemy)

                # Score
                score += 10

                canvas.itemconfig(
                    score_text,
                    text=f"Score: {score}"
                )

                break

    root.after(30, update_game)

# =========================
# KEY BINDINGS
# =========================
root.bind("<KeyPress>", key_press)
root.bind("<KeyRelease>", key_release)

# =========================
# START GAME
# =========================
update_game()

root.mainloop()